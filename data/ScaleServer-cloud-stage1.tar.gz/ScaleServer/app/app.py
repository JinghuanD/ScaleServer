from flask import Flask, jsonify
import socket
import time

app = Flask(__name__)


@app.route("/health")
def health():
    return jsonify(status="healthy", hostname=socket.gethostname())


@app.route("/work")
def work():
    start = time.perf_counter()

    result = 0
    for i in range(5_000_000):
        result += i * i

    return jsonify(
        hostname=socket.gethostname(),
        result=result,
        processing_time=time.perf_counter() - start,
    )


if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=5000,
        threaded=True,
        use_reloader=False,
    )
